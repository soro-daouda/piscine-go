#!/bin/bash
echo "Hello zed-junior!"